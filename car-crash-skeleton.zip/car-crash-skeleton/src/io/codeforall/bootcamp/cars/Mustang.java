package io.codeforall.bootcamp.cars;

public class Mustang {
}
