package io.codeforall.bootcamp.cars;

//public class Fiat extends Car {

    //public Fiat(Private pos) {
      //  super(Private pos);
    //}
//}
