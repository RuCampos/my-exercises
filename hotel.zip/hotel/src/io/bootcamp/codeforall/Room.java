package io.bootcamp.codeforall;

import javax.swing.*;
import java.lang.reflect.Array;

public class Room {

    public boolean availability;

    /*public boolean room101= true;
    public boolean room102= true;
    public boolean room103= true;*/

    public Room(boolean availability) {
        this.availability = availability;
    }


   /* public String choseRoom(){
        if (room101 == false){
            room101 = true;
            return "O seu quarto é o 101";}
            else if (room102 == false){
              room102 = true;
              return " O seu quarto é o 102";
            }
                else if(room103 ==false){
                    room103 = true;
                    return " O seu quarto é o 103";
            }
                else { return "não há quartos disponiveis";}


    }*/
}
